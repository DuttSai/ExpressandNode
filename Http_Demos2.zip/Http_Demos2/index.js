var mongoose=require("mongoose")
var http=require("http")
// var request=require("./request")
// var server=http.createServer(request.requestHandler)
const app =require("./server")
mongoose.connect("mongodb://127.0.0.1:27017/shopdb",{useNewUrlParser:true})
var server=http.createServer(app)
server.listen(5000,err=>{
    if(err){
        console.log("could not start server")
        return
    }
    console.log("started server")

})