// var path = require("path")
// var fs = require("fs")
// var layout = getViewContent('layout.html')
// exports.requestHandler = (req, res) => {
//     res.setHeader("content-type", "text/html")
//     if (req.url == '/') {
//         var body = getViewContent("index.html")
//         var content = layout.replace("{{body-content}}", body)
//         res.write(content)
//         res.end()

//     }
//     else if (req.url == '/contact') {
//         var body = getViewContent("contact.html")
//         var content = layout.replace("{{body-content}}", body)
//         res.write(content)
//         res.end()

//     }
//     else if (req.url == '/about') {
//         var body = getViewContent("about.html")
//         var content = layout.replace("{{body-content}}", body)
//         res.write(content)
//         res.end()

//     }
//     else if (req.url == '/register' && req.method == 'GET') {
//         var body = getViewContent("register.html")
//         var content = layout.replace("{{body-content}}", body)
//         res.write(content)
//         res.end()

//     }
//     else if (req.url == '/register' && req.method == "POST") {
//         var formData = ""
//         req.on("data", (chunk) => {
//             formData += chunk;
//         })
//         req.on("end", () => {
//             res.write(formData);
//             res.end()

//         })
//     }

// }
// function getViewContent(filename) {
//     var filepath = path.resolve(__dirname, "views", filename)
//     var content = fs.readFileSync(filepath)
//     return content.toString()
// }