// product-api-routes
const express=require("express")
var router=express.Router()
var Product=require("../modals/product-modal")
// GET /api/products
router.get("",(req,res)=>{
    Product.find((err,result)=>{
        if(err){
            res.status(500).header("Content-Type","application/json").json({products:undefined})
        }
        else{
            res.status(200).header("Content-Type","application/json").json({products:result})
        }
    })
})
// GET /api/products/:pname
router.get("/:pname",(req,res)=>{
    var searchValue=req.params.pname;
    Product.findOne({name:searchValue},(err,result)=>{
            if(err){
                res.status(500).header("Content-Type","application/json").json({product:undefined})
            }
            else{
                res.status(200).header("Content-Type","application/json").json({product:result})
            }
        })

})
// POST /api/products
router.post("",(req,res)=>{
    var product=new Product(req.body)
    product.save((err,result)=>{
        if(err){
            res.status(500).header("Content-Type","application/json").json({status:false})
    }
    else{
        res.status(201).header("Content-Type","application/json").json({status:true,product:result})
    }
    })
})

//PUT /api/products/:pname
router.put("/:pname",(req,res)=>{
    Product.update({name:req.params.pname},{
        $set:{
            price:req.body.price,
            quantity:req.body.quantity
        }
    },(err,result)=>{
        if(err){
            res.status(500).header("Content-Type","application/json").json({status:false})
    }
    else{
        res.status(200).header("Content-Type","application/json").json({status:true,product:result})
    }
        
    })
})

// DELETE /api/products/:pname
router.delete("/:pname",(req,res)=>{
    Product.deleteOne({name:req.params.pname},err=>{
        if(err){
            res.status(500).header("Content-Type","application/json").json({status:false})
        }
        else{
            res.status(200).header("Content-Type","application/json").json({status:true,message:"Deleted"})
        }
    })
})
module.exports=router