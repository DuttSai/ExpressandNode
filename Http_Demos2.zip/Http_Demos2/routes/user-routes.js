const User=require("../modals/user-modal")
const express=require("express")
const bcrypt=require("bcryptjs")
var router=express.Router();
router.get("/add",(req,res)=>{
    res.header("content-type","text/html").render("user-add")
})
// POST / add
router.post("/add",(req,res)=>{
    var formData=req.body;
    // console.log(formData)
    // res.send(formData)
    var salt=bcrypt.genSaltSync(5)
    var user=new User({
        firstName:formData.name,
        email:formData.email,
        password:bcrypt.hashSync(formData.password,salt)
    });
    console.log(bcrypt.compareSync(formData.password,user.password))
    user.save(err=>{
        if(err){
            res.send("error in saving data"+err);
        }
        else{
            res.send("Succesfully Saved")
        }
    })
})
module.exports=router