var request=require("supertest")
describe("#Testing express",()=>{
    it("testing GET/api/products",()=>{
        
    })
})