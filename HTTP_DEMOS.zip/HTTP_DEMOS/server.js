const express = require("express")
const bodyParser = require("body-parser")
const cookieParser = require("cookie-parser")
const session = require("express-session")
var path=require("path")
// creating a express object
var app=new express();
app.use(express.static(path.resolve(__dirname,"public")))
//configure request handlers
app.use("/about",(req,res,next)=>{
    req.author="Saidutt";
    req.verified=true;
    next()
})
app.use(cookieParser("mysecretkey"))
app.use(session({
    name:"session",
    resave:true,
    saveUninitialized:false,
    secret:"mysecretsessionkey"
}))
app.get("/",homeMiddleware,(req,res)=>{
    res.cookie("company","Capgemini",{maxAge:60000,signed:true})
    res.cookie("place","Bangalore")
    req.session.Department="product"
    req.session.Salary=20000
res.header("Content-Type","text/html").send(`<link rel="stylesheet" href="./mystyle.css"/>
                                                <h2>Home Page</h2>${req.mess}`)
})
app.get("/about",(req,res)=>{
    var companyName=req.signedCookies.company || "NILL"
    var placeName=req.cookies.place || "NILL"
    var dep=req.session.Department || 'NILL'
    var sal=req.session.Salary || 'NILL'
    req.session.destroy();
    // res.clearCookie("place")
    res.header("Content-Type","text/html").send(`<h2>About Page</h2>${req.author}
                                                    <p>Company is:${companyName}</p>
                                                    <p>Place is:${placeName}</p>
                                                    <p>Department is:${dep}</p>
                                                    <p>Salary is:${sal}</p>
                                                    `)
    })
    app.get("/contact",(req,res)=>{
        res.header("Content-Type","text/html").send("<h2>Contact Page</h2>"+req.author)
        })
        module.exports=app
        function homeMiddleware(req,res,next){
            req.mess="Hi Saidutt"
            next();
        }