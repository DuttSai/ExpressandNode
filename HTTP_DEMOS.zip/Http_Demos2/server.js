const express = require("express")
const bodyParser = require("body-parser")
const cookieParser = require("cookie-parser")
const session = require("express-session")
const cors=require("cors")

const commonRoutes=require("./routes/common-routes")
const productRoutes=require("./routes/product-routes")
const userroutes=require("./routes/user-routes")
const productAPiRoutes=require("./routes/product-api-routes")


var path=require("path")

// creating a express object

var app=new express();

app.set('views','views');
app.set('view engine',"pug")
app.use(express.static(path.resolve(__dirname,"public")))
//configure middleware
// app.use(cors({origin:/synergetics.com/,methods:["GET","POST"]}))
app.use(cors())
app.use(cookieParser("mysecretkey"))
app.use(session({
}))
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}))
//routing
app.use("/",commonRoutes)
app.use("/products",productRoutes)
app.use("/user",userroutes)
//REST
app.use("/api/products",productAPiRoutes)
module.exports=app
       