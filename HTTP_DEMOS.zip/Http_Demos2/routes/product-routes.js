const express=require("express");
var router=express.Router()
var Product=require("../modals/product-modal")
router.get("/list",(req,res)=>{
    var model={
        caption:"Products List",
    }
    Product.find((err,result)=>{
        if(err){
            model.items=undefined
        }
        else{
            model.items=result
        }
        res.header("content-type","text/html").render("product-list",model)
    })
    
})
//GET/add
router.get("/add",(req,res)=>{
    res.header("content-type","text/html").render("product-add")
})
// POST / add
router.post("/add",(req,res)=>{
    var formData=req.body;
    // console.log(formData)
    // res.send(formData)
    // var salt=bcrypt.genSaltSync(5)
    var product=new Product({
        name:formData.name,
        price:formData.price,
        quantity:formData.quantity
    });
    // console.log(bcrypt.compareSync(formData.password,user.password))
    product.save(err=>{
        if(err){
            res.send("error in saving data"+err);
        }
        else{
            res.send("Succesfully Saved")
        }
    })
})
module.exports=router