var http=require('http');
var url=require('url');
var router=require('./router');

function startserver(route,handle){
http.createServer(function(request,response){
    var reviewData="";
    var pathname=url.parse(request.url).pathname;
    console.log('request Came For request '+pathname);
    request.setEncoding('utf8');
    request.addListener('data',function(mydata){
        reviewData +=mydata;
    });

    request.addListener('end',function(){
        route(handle,pathname,response,reviewData);
    });
    

}).listen(8880);

console.log('SERVER is On & running on PORT 8880');
}

exports.startserver=startserver;