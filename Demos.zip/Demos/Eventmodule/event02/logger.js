const EventEmitter=require('events');
//console.log(EventEmitter);

var url='http:\\getloger';
class EventDemo extends EventEmitter{
 getLog(message){
	console.log(message);
	//Raise an event
this.emit('message',{id:1001,name:"Rahul"});
}
}

module.exports=EventDemo;