//let buff=Buffer.alloc(20,0b100);

//console.log(buff);

//var buffer=new Buffer([10]);
//console.log(buffer);

//var buffer=new Buffer([10]);
//console.log(buffer);

var buffer=new Buffer(12);
buffer.write('Capgemini');
console.log(buffer.toString('utf8'));
console.log(buffer.toString('utf8',0,3));
console.log(buffer.toJSON('nodejs'));
