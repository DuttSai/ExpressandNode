const fs=require('fs');

var data=fs.readFileSync('readMe.txt','utf-8');//sync-Read call-Blocking code not give next line

console.log(data);

fs.writeFileSync('writeMe.txt',data);//sync-Write call-Blocking code not give next line unless finish

