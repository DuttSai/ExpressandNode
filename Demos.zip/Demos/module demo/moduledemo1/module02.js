
/*
How to call any Module
require('./demo01');
*/

var fileexport=require('./lib/mod1');

console.log(module);
console.log(fileexport);
fileexport.doGet();
require('./lib/mod2');
