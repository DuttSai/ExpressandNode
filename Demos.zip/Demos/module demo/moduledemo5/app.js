var data=require('./lib');

data.emp();
data.pro();