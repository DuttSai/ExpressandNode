var expect=require("chai").expect;
var {getData}=require("../app/index")
describe.only('#Testing async Methods',()=>{
    it("expect getData() returns Hello",(done)=>{
        getData()
        .then(res=>{
        expect(res).to.be.equal("Hello");
        done();
       }) 
    })
})