var expect=require("chai").expect;
// var should=require("chai").should();
var assert=require("chai").assert;
var {add}=require("../app/calculator")
var {mul}=require("../app/calculator")
var {div}=require("../app/calculator")
var {sub}=require("../app/calculator")

describe("#Testing Calculate class",()=>{
    it("sample test",()=>{
        // expect(true).to.be.true
        // true.should.to.be.true
        assert(true===true,"expecting true to be true")
    })
    it("should return the sum of two numbers",()=>{
        var sum=add(2,4)
        expect(sum).to.be.equal(6)
    })
    it("should return the product of two numbers",()=>{
        var product=mul(2,4)
        expect(product).to.be.equal(8)
    })
    it("should return the divide of two numbers",()=>{
        var divide=div(4,2)
        expect(divide).to.be.equal(2)
    })
    it("should return the substract of two numbers",()=>{
        var substract=sub(4,2)
        expect(substract).to.be.equal(2)
    })
})