var expect=require("chai").expect;
var should=require("chai").should();
var _=require("lodash")
var Employee=require("../app/Employee")
describe("#Employee Test class",()=>{
describe('#Testing Constructor',()=>{
    it("should intialize members with default values",()=>{
        var emp=new Employee();
        expect(emp.name).to.be.equal("")
        expect(emp.age).to.be.equal(0)
    })
    it("should intialize members with given values",()=>{
        var emp=new Employee("sai",10);
        expect(emp.name).to.be.equal("sai")
        expect(emp.age).to.be.equal(10)
    })
})
describe("#Testing employee objects ",()=>{
    var emp;
    before(()=>{
        console.log("Before All")
        emp=new Employee("Saidutt",20)
    })
    beforeEach(()=>{
        emp=new Employee("Saidutt",20)
        console.log("Before each")
    })
    afterEach(()=>{
        console.log("After each")
    })
    after(()=>{
        console.log("After ALL")
    })
    it("Should return the name of employee",()=>{
        expect(emp.getName()).to.be.equal("Saidutt")
    })
    it("age should be finite number",()=>{
        _.isFinite(emp.age).should.be.true;
    })
})
})