class Employee{
constructor(name,age){
    this.name=name || ""
    this.age=age || 0
}
getName(){
    return this.name
}
}
module.exports=Employee