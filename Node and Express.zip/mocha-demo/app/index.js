exports.getData=()=>{
return new Promise((resolve,reject)=>{
    setTimeout(()=>{
            resolve("Hello")
    },1500)
})
}