exports.add=(a,b)=>a+b;
exports.mul=(a,b)=>a*b;
exports.div=(a,b)=>a/b;
exports.sub=(a,b)=>a-b;