function sayHello(name,cb){
    setTimeout(()=>{
        cb ("hello "+name)
    },3000)
}
console.log("calling...............")
sayHello("sai",function(res){
    console.log(res)
})

console.log("completed")