var EventE=require("events").EventEmitter
var ee=new EventE();
ee.on("Ok",()=>{
    console.log("Ok event raised")
})
ee.emit("Ok")