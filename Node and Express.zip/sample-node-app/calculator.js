exports.addFun=function (a,b){
    return a+b
}
exports.diffFun=function(a,b){
return a-b;
}
exports.mulFun=function(a,b){
return a*b
}
exports.divFun=function (a,b){
    if(b===0){
        throw new Error("cannot divide by zero")
    }
    return a/b
}
// module.exports={
//     addFun,diffFun,mulFun,divFun
// }