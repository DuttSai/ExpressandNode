function sayGoodmorning(name){
    return `Good Morning ${name}`
}
function sayGoodEvening(name){
    return `Good Evening ${name}`
}
function sayGoodafteroon(name){
    return `Good Afternon ${name}`
}
module.exports={
    sayGoodEvening,sayGoodafteroon,getGoodMorn:sayGoodmorning
}