var fs=require("fs");
var path=require("path")
exports .writeToFileStream=(filename,content)=>{
var filepath=path.resolve(__dirname,"Myfiles",filename);
var stream=fs.createWriteStream(filepath);
stream.write(content)
stream.close()
}
exports.readFromFileStream=(filename)=>{
    var filepath=path.resolve(__dirname,"Myfiles",filename);
var stream=fs.createReadStream(filepath);
var content="";
stream.on("data",(chunk)=>{
    content+=chunk
})
stream.on("end",()=>{
    console.log("streaming completed");
    console.log(content);
    stream.close()
})
}